import { describe, expect, it } from "vitest";

import { clampPercent, hydrationStatus, readinessLabel } from "../lib/fitness";
import { EMPTY_PROFILE, mergeRemoteProfile, profileToSyncPayload } from "../lib/profile";

describe("PulseFit metric helpers", () => {
  it("clamps progress to a 0–100 range", () => {
    expect(clampPercent(1000, 2000)).toBe(50);
    expect(clampPercent(2500, 2000)).toBe(100);
    expect(clampPercent(-10, 2000)).toBe(0);
  });

  it("maps readiness scores to coaching language", () => {
    expect(readinessLabel(86)).toBe("Ready to train.");
    expect(readinessLabel(68)).toBe("Train with intention.");
    expect(readinessLabel(42)).toBe("Prioritize recovery.");
  });

  it("describes hydration progress against the daily target", () => {
    expect(hydrationStatus(1000)).toBe("Halfway there.");
    expect(hydrationStatus(2000)).toBe("Target reached");
    expect(hydrationStatus(500)).toBe("Keep sipping.");
  });

  it("keeps onboarding state local while preparing profile data for sync", () => {
    const profile = { ...EMPTY_PROFILE, firstName: "Maya", heightCm: "172", onboardingComplete: true };
    expect(profileToSyncPayload(profile)).toEqual(expect.objectContaining({ firstName: "Maya", heightCm: "172" }));
    expect(profileToSyncPayload(profile)).not.toHaveProperty("onboardingComplete");
  });

  it("merges remote profile values without overwriting local completion state", () => {
    const current = { ...EMPTY_PROFILE, firstName: "Maya", onboardingComplete: true };
    const merged = mergeRemoteProfile(current, { firstName: "Alex", weightKg: "74" });
    expect(merged.firstName).toBe("Alex");
    expect(merged.weightKg).toBe("74");
    expect(merged.onboardingComplete).toBe(true);
  });
});
