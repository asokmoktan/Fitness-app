/** @type {const} */
const themeColors = {
  primary: { light: '#C7F36B', dark: '#C7F36B' },
  background: { light: '#F6F4EC', dark: '#171A17' },
  surface: { light: '#FFFFFF', dark: '#222822' },
  foreground: { light: '#171A17', dark: '#F6F4EC' },
  muted: { light: '#6E746B', dark: '#AAB2A2' },
  border: { light: '#DDE0D4', dark: '#3C463B' },
  success: { light: '#5C9A45', dark: '#8BCB68' },
  warning: { light: '#E4A548', dark: '#F7C66E' },
  error: { light: '#FF8065', dark: '#FF9B86' },
};

module.exports = { themeColors };
