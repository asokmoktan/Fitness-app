CREATE TABLE `fitnessProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`firstName` text,
	`age` varchar(16),
	`sex` varchar(64),
	`goal` varchar(64),
	`heightCm` varchar(16),
	`weightKg` varchar(16),
	`bodyFat` varchar(16),
	`targetWeightKg` varchar(16),
	`activityLevel` varchar(64),
	`trainingDays` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fitnessProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `fitnessProfiles_userId_unique` UNIQUE(`userId`)
);
