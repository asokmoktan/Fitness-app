import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const fitnessProfiles = mysqlTable("fitnessProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  firstName: text("firstName"),
  age: varchar("age", { length: 16 }),
  sex: varchar("sex", { length: 64 }),
  goal: varchar("goal", { length: 64 }),
  heightCm: varchar("heightCm", { length: 16 }),
  weightKg: varchar("weightKg", { length: 16 }),
  bodyFat: varchar("bodyFat", { length: 16 }),
  targetWeightKg: varchar("targetWeightKg", { length: 16 }),
  activityLevel: varchar("activityLevel", { length: 64 }),
  trainingDays: varchar("trainingDays", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FitnessProfile = typeof fitnessProfiles.$inferSelect;
export type InsertFitnessProfile = typeof fitnessProfiles.$inferInsert;
