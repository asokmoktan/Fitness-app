export function clampPercent(value: number, target: number) {
  if (target <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((value / target) * 100)));
}

export function readinessLabel(score: number) {
  if (score >= 80) return "Ready to train.";
  if (score >= 60) return "Train with intention.";
  return "Prioritize recovery.";
}

export function hydrationStatus(consumedMl: number, targetMl = 2000) {
  const percent = clampPercent(consumedMl, targetMl);
  if (percent >= 100) return "Target reached";
  if (percent >= 50) return "Halfway there.";
  return "Keep sipping.";
}
