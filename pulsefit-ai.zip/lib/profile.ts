import AsyncStorage from "@react-native-async-storage/async-storage";

export type FitnessProfile = {
  firstName: string;
  age: string;
  sex: string;
  goal: string;
  heightCm: string;
  weightKg: string;
  bodyFat: string;
  targetWeightKg: string;
  activityLevel: string;
  trainingDays: string;
  onboardingComplete: boolean;
};

export const EMPTY_PROFILE: FitnessProfile = {
  firstName: "",
  age: "",
  sex: "",
  goal: "",
  heightCm: "",
  weightKg: "",
  bodyFat: "",
  targetWeightKg: "",
  activityLevel: "",
  trainingDays: "",
  onboardingComplete: false,
};

const PROFILE_KEY = "pulsefit-profile-v1";
const GUEST_KEY = "pulsefit-guest-mode-v1";

export async function getProfile(): Promise<FitnessProfile> {
  try {
    const raw = await AsyncStorage.getItem(PROFILE_KEY);
    return raw ? { ...EMPTY_PROFILE, ...JSON.parse(raw) } : EMPTY_PROFILE;
  } catch {
    return EMPTY_PROFILE;
  }
}

export async function saveProfile(profile: Partial<FitnessProfile>) {
  const current = await getProfile();
  const next = { ...current, ...profile };
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(next));
  return next;
}

export async function markOnboardingComplete() {
  return saveProfile({ onboardingComplete: true });
}

export async function setGuestMode(value: boolean) {
  if (value) await AsyncStorage.setItem(GUEST_KEY, "true");
  else await AsyncStorage.removeItem(GUEST_KEY);
}

export async function isGuestMode() {
  return (await AsyncStorage.getItem(GUEST_KEY)) === "true";
}

export function profileToSyncPayload(profile: FitnessProfile) {
  const { onboardingComplete: _onboardingComplete, ...syncable } = profile;
  return syncable;
}

export function mergeRemoteProfile(current: FitnessProfile, remote: Partial<Record<keyof FitnessProfile, string | null>> | null | undefined) {
  if (!remote) return current;
  const next = { ...current };
  (Object.keys(EMPTY_PROFILE) as Array<keyof FitnessProfile>).forEach((key) => {
    if (key === "onboardingComplete") return;
    const value = remote[key];
    if (typeof value === "string") next[key] = value;
  });
  return next;
}
