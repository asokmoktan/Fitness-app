import { useEffect, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Redirect } from "expo-router";

import { useAuth } from "@/hooks/use-auth";
import { getProfile, isGuestMode } from "@/lib/profile";

export default function EntryGate() {
  const { isAuthenticated, loading } = useAuth();
  const [destination, setDestination] = useState<"loading" | "login" | "onboarding" | "home">("loading");

  useEffect(() => {
    let cancelled = false;
    async function resolveDestination() {
      if (loading) return;
      if (!isAuthenticated && !(await isGuestMode())) {
        if (!cancelled) setDestination("login");
        return;
      }
      const profile = await getProfile();
      if (!cancelled) setDestination(profile.onboardingComplete ? "home" : "onboarding");
    }
    resolveDestination();
    return () => { cancelled = true; };
  }, [isAuthenticated, loading]);

  if (destination === "login") return <Redirect href="/login" />;
  if (destination === "onboarding") return <Redirect href="/onboarding" />;
  if (destination === "home") return <Redirect href="/(tabs)" />;

  return <View style={styles.loading}><Text style={styles.logo}>PULSEFIT</Text><ActivityIndicator color="#C7F36B" size="small" /></View>;
}

const styles = StyleSheet.create({ loading: { flex: 1, backgroundColor: "#171A17", alignItems: "center", justifyContent: "center", gap: 18 }, logo: { color: "#C7F36B", fontSize: 24, fontWeight: "900", letterSpacing: 3 } });
