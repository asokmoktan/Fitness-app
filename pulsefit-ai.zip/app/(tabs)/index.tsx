import { useEffect, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { getProfile } from "@/lib/profile";

const palette = {
  ink: "#171A17",
  muted: "#6E746B",
  line: "#DDE0D4",
  bone: "#F6F4EC",
  card: "#FFFFFF",
  lime: "#C7F36B",
  limeSoft: "#EAF6C9",
  coral: "#FF8065",
  coralSoft: "#FFE3DC",
  lavender: "#E4DFFF",
};

function feedback() {
  if (Platform.OS !== "web") {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }
}

function ProgressBar({ value, color = palette.lime }: { value: number; color?: string }) {
  return (
    <View style={styles.progressTrack}>
      <View style={[styles.progressFill, { width: `${Math.min(value, 100)}%`, backgroundColor: color }]} />
    </View>
  );
}

function MetricCard({
  eyebrow,
  value,
  unit,
  caption,
  icon,
  backgroundColor,
  iconColor = palette.ink,
}: {
  eyebrow: string;
  value: string;
  unit: string;
  caption: string;
  icon: "waveform.path.ecg" | "moon.stars.fill" | "drop.fill";
  backgroundColor: string;
  iconColor?: string;
}) {
  return (
    <View style={[styles.metricCard, { backgroundColor }]}> 
      <View style={styles.metricHeader}>
        <Text style={styles.eyebrow}>{eyebrow}</Text>
        <IconSymbol name={icon} size={18} color={iconColor} />
      </View>
      <View style={styles.metricValueRow}>
        <Text style={styles.metricValue}>{value}</Text>
        <Text style={styles.metricUnit}>{unit}</Text>
      </View>
      <Text style={styles.metricCaption}>{caption}</Text>
    </View>
  );
}

export default function TodayScreen() {
  const [started, setStarted] = useState(false);
  const [water, setWater] = useState(4);
  const [message, setMessage] = useState("");
  const [firstName, setFirstName] = useState("Maya");

  useEffect(() => {
    getProfile().then((profile) => {
      if (profile.firstName.trim()) setFirstName(profile.firstName.trim());
    });
  }, []);

  const showMessage = (nextMessage: string) => {
    feedback();
    setMessage(nextMessage);
    setTimeout(() => setMessage(""), 2400);
  };

  const addWater = () => {
    feedback();
    setWater((current) => Math.min(current + 1, 8));
    setMessage("Hydration logged · +250 ml");
    setTimeout(() => setMessage(""), 2400);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topRow}>
          <View>
            <Text style={styles.dateLabel}>THURSDAY, SEP 24</Text>
            <Text style={styles.greeting}>Good morning, {firstName}</Text>
          </View>
          <Pressable
            accessibilityLabel="Open profile settings"
            onPress={() => router.push("/settings")}
            style={({ pressed }) => [styles.avatar, pressed && styles.pressed]}
          >
            <Text style={styles.avatarText}>MC</Text>
            <View style={styles.notificationDot} />
          </Pressable>
        </View>

        <View style={styles.readinessCard}>
          <View style={styles.readinessTop}>
            <View>
              <Text style={styles.cardEyebrow}>AI READINESS CHECK</Text>
              <Text style={styles.readinessTitle}>Your body is ready.</Text>
              <Text style={styles.readinessSub}>Good sleep. Low stress. Let’s put it to work.</Text>
            </View>
            <View style={styles.scoreCircle}>
              <Text style={styles.scoreNumber}>86</Text>
              <Text style={styles.scoreLabel}>READY</Text>
            </View>
          </View>
          <View style={styles.sparkline}>
            {[42, 54, 48, 68, 61, 78, 86].map((height, index) => (
              <View
                key={index}
                style={[styles.sparkBar, { height, backgroundColor: index === 6 ? palette.ink : "rgba(23,26,23,0.18)" }]}
              />
            ))}
          </View>
          <View style={styles.readinessFooter}>
            <Text style={styles.readinessFooterText}>+8 vs. yesterday</Text>
            <Pressable onPress={() => showMessage("Readiness is calculated from sleep, stress, and recent load.")} style={styles.infoButton}>
              <IconSymbol name="info.circle" size={16} color={palette.ink} />
            </Pressable>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Your signals</Text>
          <Text style={styles.sectionMeta}>LIVE SYNC</Text>
        </View>
        <View style={styles.metricGrid}>
          <MetricCard eyebrow="RECOVERY" value="86" unit="/ 100" caption="Above your 7-day avg" icon="waveform.path.ecg" backgroundColor={palette.limeSoft} />
          <MetricCard eyebrow="SLEEP" value="7.8" unit="hrs" caption="92% sleep quality" icon="moon.stars.fill" backgroundColor={palette.lavender} />
          <MetricCard eyebrow="HYDRATION" value={`${water}`} unit="/ 8" caption={`${water * 250} ml logged today`} icon="drop.fill" backgroundColor={palette.coralSoft} />
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Up next</Text>
          <Text style={styles.sectionMeta}>10:30 AM</Text>
        </View>
        <View style={styles.workoutCard}>
          <View style={styles.workoutGraphic}>
            <IconSymbol name="figure.strengthtraining.traditional" size={30} color={palette.lime} />
            <Text style={styles.graphicLabel}>A</Text>
          </View>
          <View style={styles.workoutInfo}>
            <Text style={styles.workoutKicker}>THURSDAY · UPPER A</Text>
            <Text style={styles.workoutTitle}>Strength + volume</Text>
            <Text style={styles.workoutMeta}>6 exercises · 48 min · Moderate</Text>
            <Pressable
              onPress={() => {
                feedback();
                setStarted((current) => !current);
                setMessage(started ? "Workout paused" : "Workout started · let’s go");
                setTimeout(() => setMessage(""), 2400);
              }}
              style={({ pressed }) => [styles.primaryButton, pressed && styles.primaryButtonPressed]}
            >
              <IconSymbol name={started ? "pause.fill" : "play.fill"} size={15} color={palette.ink} />
              <Text style={styles.primaryButtonText}>{started ? "Pause session" : "Start workout"}</Text>
            </Pressable>
          </View>
          <IconSymbol name="chevron.right" size={20} color={palette.muted} />
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Today’s fuel</Text>
          <Pressable onPress={() => showMessage("Fuel plan opened in the Fuel tab")}>
            <Text style={styles.linkText}>VIEW PLAN</Text>
          </Pressable>
        </View>
        <View style={styles.fuelCard}>
          <View style={styles.fuelTopRow}>
            <View>
              <Text style={styles.fuelKicker}>CALORIES</Text>
              <Text style={styles.fuelValue}>1,240 <Text style={styles.fuelTarget}>/ 2,180 kcal</Text></Text>
            </View>
            <View style={styles.calorieRing}>
              <Text style={styles.ringPercent}>57%</Text>
            </View>
          </View>
          <ProgressBar value={57} color={palette.coral} />
          <View style={styles.macroRow}>
            <View style={styles.macroItem}><View style={[styles.macroDot, { backgroundColor: palette.lime }]} /><Text style={styles.macroText}>Protein 92g</Text></View>
            <View style={styles.macroItem}><View style={[styles.macroDot, { backgroundColor: palette.lavender }]} /><Text style={styles.macroText}>Carbs 138g</Text></View>
            <View style={styles.macroItem}><View style={[styles.macroDot, { backgroundColor: palette.coral }]} /><Text style={styles.macroText}>Fat 42g</Text></View>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Coach note</Text>
          <IconSymbol name="sparkles" size={18} color={palette.coral} />
        </View>
        <Pressable onPress={() => Alert.alert("PulseFit Coach", "You’re trending well. Keep the working sets at RPE 8 today and add a carb-forward snack 90 minutes before training.")} style={({ pressed }) => [styles.coachCard, pressed && styles.pressed]}>
          <View style={styles.coachIcon}><IconSymbol name="sparkles" size={18} color={palette.ink} /></View>
          <View style={styles.coachCopy}>
            <Text style={styles.coachTitle}>A small adjustment for a stronger session</Text>
            <Text style={styles.coachBody}>Your recovery is up 8 points. Keep today’s working sets at RPE 8 and fuel with 30–50g carbs before training.</Text>
          </View>
          <IconSymbol name="chevron.right" size={18} color={palette.muted} />
        </Pressable>

        <Pressable onPress={addWater} style={({ pressed }) => [styles.waterButton, pressed && styles.primaryButtonPressed]}>
          <IconSymbol name="plus" size={16} color={palette.ink} />
          <Text style={styles.waterButtonText}>Log 250 ml water</Text>
        </Pressable>
      </ScrollView>
      {message ? <View style={styles.toast}><IconSymbol name="checkmark" size={16} color={palette.ink} /><Text style={styles.toastText}>{message}</Text></View> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 32, gap: 18 },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  dateLabel: { color: palette.muted, fontSize: 11, fontWeight: "800", letterSpacing: 1.2 },
  greeting: { color: palette.ink, fontSize: 27, lineHeight: 33, fontWeight: "800", letterSpacing: -0.8, marginTop: 5 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: palette.ink, alignItems: "center", justifyContent: "center", position: "relative" },
  avatarText: { color: palette.lime, fontWeight: "800", fontSize: 12 },
  notificationDot: { position: "absolute", right: 1, top: 0, width: 10, height: 10, borderRadius: 5, backgroundColor: palette.coral, borderWidth: 2, borderColor: palette.bone },
  pressed: { opacity: 0.72 },
  readinessCard: { backgroundColor: palette.lime, borderRadius: 26, padding: 20, minHeight: 204 },
  readinessTop: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
  cardEyebrow: { color: "rgba(23,26,23,0.65)", fontSize: 10, fontWeight: "900", letterSpacing: 1.2 },
  readinessTitle: { color: palette.ink, fontSize: 26, lineHeight: 30, fontWeight: "900", letterSpacing: -0.8, marginTop: 10 },
  readinessSub: { color: "rgba(23,26,23,0.72)", fontSize: 13, lineHeight: 18, maxWidth: 205, marginTop: 6 },
  scoreCircle: { width: 68, height: 68, borderRadius: 34, backgroundColor: "rgba(255,255,255,0.45)", alignItems: "center", justifyContent: "center" },
  scoreNumber: { color: palette.ink, fontSize: 24, fontWeight: "900", lineHeight: 27 },
  scoreLabel: { color: "rgba(23,26,23,0.62)", fontSize: 8, fontWeight: "900", letterSpacing: 1 },
  sparkline: { height: 44, flexDirection: "row", alignItems: "flex-end", gap: 7, marginTop: 20 },
  sparkBar: { width: 10, borderRadius: 5 },
  readinessFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8 },
  readinessFooterText: { color: palette.ink, fontSize: 12, fontWeight: "800" },
  infoButton: { padding: 2 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 2 },
  sectionTitle: { color: palette.ink, fontSize: 17, fontWeight: "800", letterSpacing: -0.2 },
  sectionMeta: { color: palette.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  linkText: { color: palette.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  metricGrid: { flexDirection: "row", gap: 9 },
  metricCard: { flex: 1, minHeight: 125, borderRadius: 18, padding: 13, justifyContent: "space-between" },
  metricHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { color: palette.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  metricValueRow: { flexDirection: "row", alignItems: "baseline", gap: 3, marginTop: 10 },
  metricValue: { color: palette.ink, fontSize: 25, fontWeight: "900", letterSpacing: -1 },
  metricUnit: { color: palette.muted, fontSize: 11, fontWeight: "700" },
  metricCaption: { color: palette.muted, fontSize: 10, lineHeight: 14, marginTop: 5 },
  workoutCard: { backgroundColor: palette.card, borderRadius: 22, padding: 14, flexDirection: "row", alignItems: "flex-start", gap: 12, shadowColor: "#171A17", shadowOpacity: 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 2 },
  workoutGraphic: { width: 54, height: 70, borderRadius: 16, backgroundColor: palette.ink, alignItems: "center", justifyContent: "center", gap: 5 },
  graphicLabel: { color: palette.lime, fontSize: 11, fontWeight: "900" },
  workoutInfo: { flex: 1 },
  workoutKicker: { color: palette.coral, fontSize: 9, fontWeight: "900", letterSpacing: 0.9 },
  workoutTitle: { color: palette.ink, fontSize: 17, fontWeight: "800", marginTop: 5 },
  workoutMeta: { color: palette.muted, fontSize: 11, marginTop: 4 },
  primaryButton: { marginTop: 12, alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: palette.lime, paddingVertical: 10, paddingHorizontal: 13, borderRadius: 12 },
  primaryButtonPressed: { transform: [{ scale: 0.97 }], opacity: 0.9 },
  primaryButtonText: { color: palette.ink, fontSize: 11, fontWeight: "900" },
  fuelCard: { backgroundColor: palette.card, borderRadius: 22, padding: 17, shadowColor: "#171A17", shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  fuelTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  fuelKicker: { color: palette.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  fuelValue: { color: palette.ink, fontSize: 24, fontWeight: "900", marginTop: 4, letterSpacing: -0.6 },
  fuelTarget: { color: palette.muted, fontSize: 12, fontWeight: "700", letterSpacing: 0 },
  calorieRing: { width: 48, height: 48, borderRadius: 24, borderWidth: 5, borderColor: palette.coralSoft, borderTopColor: palette.coral, alignItems: "center", justifyContent: "center" },
  ringPercent: { color: palette.coral, fontSize: 11, fontWeight: "900" },
  progressTrack: { height: 7, backgroundColor: "#EEF0E8", borderRadius: 4, overflow: "hidden", marginTop: 15 },
  progressFill: { height: "100%", borderRadius: 4 },
  macroRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 13 },
  macroItem: { flexDirection: "row", alignItems: "center", gap: 5 },
  macroDot: { width: 7, height: 7, borderRadius: 4 },
  macroText: { color: palette.muted, fontSize: 10, fontWeight: "700" },
  coachCard: { backgroundColor: palette.ink, borderRadius: 22, padding: 16, flexDirection: "row", alignItems: "center", gap: 12 },
  coachIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: palette.lime, alignItems: "center", justifyContent: "center" },
  coachCopy: { flex: 1 },
  coachTitle: { color: "#FFFFFF", fontSize: 14, lineHeight: 18, fontWeight: "800" },
  coachBody: { color: "#B8C0B2", fontSize: 11, lineHeight: 16, marginTop: 5 },
  waterButton: { minHeight: 48, borderWidth: 1, borderColor: palette.line, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.5)" },
  waterButtonText: { color: palette.ink, fontSize: 12, fontWeight: "800" },
  toast: { position: "absolute", bottom: 17, left: 20, right: 20, backgroundColor: palette.ink, borderRadius: 14, padding: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, shadowColor: "#000", shadowOpacity: 0.2, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 5 },
  toastText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
});
