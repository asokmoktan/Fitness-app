import { useState } from "react";
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";

const colors = { ink: "#171A17", muted: "#6E746B", bone: "#F6F4EC", card: "#FFFFFF", line: "#DDE0D4", lime: "#C7F36B", limeSoft: "#EAF6C9", coral: "#FF8065", coralSoft: "#FFE3DC", lavender: "#E4DFFF" };
const meals = [
  { id: "1", type: "BREAKFAST", name: "Greek yogurt + berries", detail: "320 kcal · 24g protein", color: colors.limeSoft, icon: "sun.max.fill" as const },
  { id: "2", type: "LUNCH", name: "Chicken grain bowl", detail: "540 kcal · 42g protein", color: colors.lavender, icon: "fork.knife" as const },
  { id: "3", type: "SNACK", name: "Pre-workout fuel", detail: "210 kcal · 6g protein", color: colors.coralSoft, icon: "bolt.fill" as const },
  { id: "4", type: "DINNER", name: "Planned for later", detail: "Aim for 610 kcal · 38g protein", color: "#EEF0E8", icon: "moon.stars.fill" as const },
];

function ping() { if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
function Progress({ value, color }: { value: number; color: string }) { return <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${value}%`, backgroundColor: color }]} /></View>; }

export default function FuelScreen() {
  const [logged, setLogged] = useState<string[]>(["1", "2"]);
  const [notice, setNotice] = useState("");
  const logMeal = (id: string, name: string) => {
    ping();
    setLogged((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
    setNotice(logged.includes(id) ? `${name} removed from today` : `${name} logged to today`);
    setTimeout(() => setNotice(""), 2200);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <FlatList
        data={meals}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <>
            <View style={styles.headerRow}><View><Text style={styles.eyebrow}>NUTRITION INTELLIGENCE</Text><Text style={styles.title}>Eat with intent.</Text></View><Pressable onPress={() => setNotice("Barcode scanner coming soon")} style={({ pressed }) => [styles.roundButton, pressed && styles.pressed]}><IconSymbol name="barcode.viewfinder" size={19} color={colors.ink} /></Pressable></View>
            <View style={styles.calorieCard}><View style={styles.calorieHeader}><View><Text style={styles.cardLabel}>THURSDAY’S TARGET</Text><Text style={styles.calorieValue}>1,240 <Text style={styles.calorieTarget}>/ 2,180 kcal</Text></Text><Text style={styles.calorieCaption}>You have enough room for a full dinner + recovery snack.</Text></View><View style={styles.calorieRing}><Text style={styles.ringValue}>57%</Text><Text style={styles.ringLabel}>EATEN</Text></View></View><Progress value={57} color={colors.coral} /><View style={styles.macroGrid}><View><Text style={styles.macroLabel}>PROTEIN</Text><Text style={styles.macroValue}>92<Text style={styles.macroUnit}> / 150g</Text></Text><Progress value={61} color={colors.lime} /></View><View><Text style={styles.macroLabel}>CARBS</Text><Text style={styles.macroValue}>138<Text style={styles.macroUnit}> / 250g</Text></Text><Progress value={55} color={colors.lavender} /></View><View><Text style={styles.macroLabel}>FAT</Text><Text style={styles.macroValue}>42<Text style={styles.macroUnit}> / 73g</Text></Text><Progress value={58} color={colors.coral} /></View></View></View>
            <View style={styles.sectionRow}><Text style={styles.sectionTitle}>Meal plan</Text><Text style={styles.sectionMeta}>4 ENTRIES</Text></View>
          </>
        }
        renderItem={({ item }) => {
          const isLogged = logged.includes(item.id);
          return <Pressable onPress={() => logMeal(item.id, item.name)} style={({ pressed }) => [styles.mealCard, pressed && styles.pressed]}><View style={[styles.mealIcon, { backgroundColor: item.color }]}><IconSymbol name={item.icon} size={18} color={colors.ink} /></View><View style={styles.mealCopy}><Text style={styles.mealType}>{item.type}</Text><Text style={[styles.mealName, !isLogged && styles.mealNameMuted]}>{item.name}</Text><Text style={styles.mealDetail}>{item.detail}</Text></View><View style={[styles.checkCircle, isLogged && styles.checkCircleActive]}>{isLogged ? <IconSymbol name="checkmark" size={15} color={colors.ink} /> : <IconSymbol name="plus" size={15} color={colors.muted} />}</View></Pressable>;
        }}
        ListFooterComponent={<><View style={styles.sectionRow}><Text style={styles.sectionTitle}>Hydration</Text><Text style={styles.sectionMeta}>4 / 8 GLASSES</Text></View><View style={styles.waterCard}><View style={styles.waterTop}><View><Text style={styles.waterTitle}>Halfway there.</Text><Text style={styles.waterCaption}>1,000 ml of 2,000 ml logged</Text></View><IconSymbol name="drop.fill" size={26} color={colors.coral} /></View><Progress value={50} color={colors.coral} /><View style={styles.glasses}>{Array.from({ length: 8 }).map((_, index) => <Pressable key={index} onPress={() => setNotice(index < 4 ? "That glass is already logged" : `Glass ${index + 1} added`)} style={[styles.glass, index < 4 && styles.glassFilled]}><IconSymbol name="drop.fill" size={16} color={index < 4 ? colors.ink : colors.muted} /></Pressable>)}</View></View><Pressable onPress={() => { ping(); setNotice("250 ml water logged"); setTimeout(() => setNotice(""), 2200); }} style={({ pressed }) => [styles.addButton, pressed && styles.addPressed]}><IconSymbol name="plus" size={16} color={colors.ink} /><Text style={styles.addButtonText}>Log 250 ml</Text></Pressable></>}
      />
      {notice ? <View style={styles.toast}><IconSymbol name="checkmark" size={15} color={colors.ink} /><Text style={styles.toastText}>{notice}</Text></View> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 32, gap: 12 },
  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 18 },
  eyebrow: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.2 },
  title: { color: colors.ink, fontSize: 28, lineHeight: 34, fontWeight: "900", letterSpacing: -1, marginTop: 5 },
  roundButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  pressed: { opacity: 0.7 },
  calorieCard: { backgroundColor: colors.card, borderRadius: 24, padding: 18, shadowColor: colors.ink, shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  calorieHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cardLabel: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  calorieValue: { color: colors.ink, fontSize: 24, fontWeight: "900", letterSpacing: -0.8, marginTop: 7 },
  calorieTarget: { color: colors.muted, fontSize: 12, fontWeight: "700", letterSpacing: 0 },
  calorieCaption: { color: colors.muted, fontSize: 11, lineHeight: 16, maxWidth: 225, marginTop: 5 },
  calorieRing: { width: 62, height: 62, borderRadius: 31, borderWidth: 6, borderColor: colors.coralSoft, borderTopColor: colors.coral, alignItems: "center", justifyContent: "center" },
  ringValue: { color: colors.coral, fontSize: 16, fontWeight: "900" },
  ringLabel: { color: colors.muted, fontSize: 8, fontWeight: "900", letterSpacing: 0.8, marginTop: 1 },
  progressTrack: { backgroundColor: "#EEF0E8", height: 7, borderRadius: 4, overflow: "hidden", marginTop: 15 },
  progressFill: { height: "100%", borderRadius: 4 },
  macroGrid: { flexDirection: "row", gap: 12, marginTop: 18 },
  macroGridItem: { flex: 1 },
  macroLabel: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  macroValue: { color: colors.ink, fontSize: 16, fontWeight: "900", marginTop: 5 },
  macroUnit: { color: colors.muted, fontSize: 10, fontWeight: "700" },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 11, marginBottom: 2 },
  sectionTitle: { color: colors.ink, fontSize: 17, fontWeight: "800" },
  sectionMeta: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  mealCard: { backgroundColor: colors.card, borderRadius: 19, padding: 13, flexDirection: "row", alignItems: "center", gap: 12 },
  mealIcon: { width: 45, height: 45, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  mealCopy: { flex: 1 },
  mealType: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.9 },
  mealName: { color: colors.ink, fontSize: 14, fontWeight: "800", marginTop: 4 },
  mealNameMuted: { color: colors.muted },
  mealDetail: { color: colors.muted, fontSize: 11, marginTop: 3 },
  checkCircle: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  checkCircleActive: { backgroundColor: colors.lime, borderColor: colors.lime },
  waterCard: { backgroundColor: colors.coralSoft, borderRadius: 22, padding: 17 },
  waterTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  waterTitle: { color: colors.ink, fontSize: 18, fontWeight: "900" },
  waterCaption: { color: colors.muted, fontSize: 11, marginTop: 4 },
  glasses: { flexDirection: "row", justifyContent: "space-between", marginTop: 17 },
  glass: { width: 29, height: 29, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.6)", alignItems: "center", justifyContent: "center" },
  glassFilled: { backgroundColor: colors.coral },
  addButton: { height: 50, borderRadius: 15, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, marginTop: 2 },
  addPressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
  addButtonText: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  toast: { position: "absolute", bottom: 18, left: 20, right: 20, borderRadius: 14, backgroundColor: colors.ink, padding: 13, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 8 },
  toastText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
});
