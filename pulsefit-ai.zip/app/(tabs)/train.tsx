import { useState } from "react";
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";

const colors = { ink: "#171A17", muted: "#6E746B", bone: "#F6F4EC", card: "#FFFFFF", line: "#DDE0D4", lime: "#C7F36B", coral: "#FF8065", lavender: "#E4DFFF" };

type Session = { id: string; day: string; label: string; title: string; detail: string; duration: string; state: "done" | "today" | "upcoming" };
const sessions: Session[] = [
  { id: "1", day: "MON", label: "LOWER A", title: "Squat strength", detail: "6 exercises · 52 min", duration: "DONE", state: "done" },
  { id: "2", day: "THU", label: "UPPER A", title: "Strength + volume", detail: "6 exercises · 48 min", duration: "TODAY", state: "today" },
  { id: "3", day: "SAT", label: "LOWER B", title: "Hinge + accessories", detail: "7 exercises · 55 min", duration: "SAT", state: "upcoming" },
];

function ping() {
  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

export default function TrainScreen() {
  const [active, setActive] = useState(false);
  const [notice, setNotice] = useState("");

  const trigger = (text: string) => {
    ping();
    setNotice(text);
    setTimeout(() => setNotice(""), 2200);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <FlatList
        data={sessions}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <>
            <View style={styles.headerRow}>
              <View>
                <Text style={styles.eyebrow}>TRAINING PLAN</Text>
                <Text style={styles.title}>Build your base.</Text>
              </View>
              <Pressable onPress={() => trigger("Plan settings are ready to customize")} style={({ pressed }) => [styles.roundButton, pressed && styles.pressed]}>
                <IconSymbol name="slider.horizontal.3" size={18} color={colors.ink} />
              </Pressable>
            </View>
            <View style={styles.planCard}>
              <View style={styles.planTop}>
                <View><Text style={styles.planLabel}>HYPERTROPHY BLOCK</Text><Text style={styles.planTitle}>Foundation / 8 weeks</Text></View>
                <Text style={styles.planWeek}>03 <Text style={styles.planWeekMuted}>/ 08</Text></Text>
              </View>
              <View style={styles.weekTrack}>
                {[1, 2, 3, 4, 5, 6, 7, 8].map((week) => <View key={week} style={[styles.weekDot, week <= 3 && styles.weekDotActive, week === 3 && styles.weekDotCurrent]} />)}
              </View>
              <View style={styles.planFooter}><Text style={styles.planFooterText}>12 sessions completed</Text><Text style={styles.planFooterText}>72% consistency</Text></View>
            </View>
            <View style={styles.sectionRow}><Text style={styles.sectionTitle}>This week</Text><Text style={styles.sectionMeta}>3 SESSIONS</Text></View>
          </>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => trigger(item.state === "done" ? "Session history opened" : item.state === "today" ? "Today’s session selected" : "Session preview opened")} style={({ pressed }) => [styles.sessionCard, item.state === "today" && styles.sessionCardToday, pressed && styles.pressed]}>
            <View style={[styles.dayBlock, item.state === "today" && styles.dayBlockToday]}><Text style={[styles.dayText, item.state === "today" && styles.dayTextToday]}>{item.day}</Text></View>
            <View style={styles.sessionCopy}><Text style={[styles.sessionLabel, item.state === "today" && styles.todayLabel]}>{item.label}</Text><Text style={styles.sessionTitle}>{item.title}</Text><Text style={styles.sessionDetail}>{item.detail}</Text></View>
            <View style={styles.sessionRight}>{item.state === "done" ? <IconSymbol name="checkmark" size={18} color="#5C9A45" /> : <Text style={[styles.sessionStatus, item.state === "today" && styles.todayStatus]}>{item.duration}</Text>}<IconSymbol name="chevron.right" size={17} color={colors.muted} /></View>
          </Pressable>
        )}
        ListFooterComponent={
          <>
            <View style={styles.sectionRow}><Text style={styles.sectionTitle}>Volume signal</Text><Text style={styles.sectionMeta}>LAST 14 DAYS</Text></View>
            <View style={styles.signalCard}>
              <View style={styles.signalIcon}><IconSymbol name="chart.xyaxis.line" size={18} color={colors.ink} /></View>
              <View style={styles.signalCopy}><Text style={styles.signalTitle}>Load is trending right</Text><Text style={styles.signalBody}>You’re adding volume without pushing past your recovery threshold. Keep the current set count this week.</Text></View>
            </View>
            <Pressable onPress={() => { ping(); setActive((value) => !value); trigger(active ? "Session paused" : "Session ready · first set queued"); }} style={({ pressed }) => [styles.startButton, pressed && styles.startPressed]}><IconSymbol name={active ? "pause.fill" : "play.fill"} size={16} color={colors.ink} /><Text style={styles.startButtonText}>{active ? "Pause current session" : "Start today’s session"}</Text></Pressable>
          </>
        }
      />
      {notice ? <View style={styles.toast}><IconSymbol name="checkmark" size={15} color={colors.ink} /><Text style={styles.toastText}>{notice}</Text></View> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 32, gap: 12 },
  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 18 },
  eyebrow: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.3 },
  title: { color: colors.ink, fontSize: 28, lineHeight: 34, fontWeight: "900", letterSpacing: -1, marginTop: 5 },
  roundButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  pressed: { opacity: 0.7 },
  planCard: { backgroundColor: colors.ink, borderRadius: 24, padding: 18, marginBottom: 7 },
  planTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  planLabel: { color: colors.lime, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  planTitle: { color: "#FFFFFF", fontSize: 20, fontWeight: "800", marginTop: 7 },
  planWeek: { color: colors.lime, fontSize: 26, fontWeight: "900", letterSpacing: -1 },
  planWeekMuted: { color: "#808A7B", fontSize: 13, fontWeight: "700" },
  weekTrack: { flexDirection: "row", gap: 7, marginTop: 25 },
  weekDot: { flex: 1, height: 5, borderRadius: 4, backgroundColor: "#3B4538" },
  weekDotActive: { backgroundColor: "#758467" },
  weekDotCurrent: { backgroundColor: colors.lime },
  planFooter: { flexDirection: "row", justifyContent: "space-between", marginTop: 13 },
  planFooterText: { color: "#AAB2A2", fontSize: 10, fontWeight: "700" },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 11, marginBottom: 2 },
  sectionTitle: { color: colors.ink, fontSize: 17, fontWeight: "800" },
  sectionMeta: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  sessionCard: { backgroundColor: colors.card, borderRadius: 19, padding: 13, flexDirection: "row", alignItems: "center", gap: 12, borderWidth: 1, borderColor: "transparent" },
  sessionCardToday: { borderColor: colors.lime, shadowColor: "#171A17", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  dayBlock: { width: 45, height: 53, borderRadius: 14, backgroundColor: "#EEF0E8", alignItems: "center", justifyContent: "center" },
  dayBlockToday: { backgroundColor: colors.lime },
  dayText: { color: colors.muted, fontSize: 11, fontWeight: "900", letterSpacing: 0.8 },
  dayTextToday: { color: colors.ink },
  sessionCopy: { flex: 1 },
  sessionLabel: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  todayLabel: { color: "#75942F" },
  sessionTitle: { color: colors.ink, fontSize: 15, fontWeight: "800", marginTop: 4 },
  sessionDetail: { color: colors.muted, fontSize: 11, marginTop: 3 },
  sessionRight: { alignItems: "flex-end", gap: 12 },
  sessionStatus: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.7 },
  todayStatus: { color: colors.coral },
  signalCard: { backgroundColor: colors.lavender, borderRadius: 20, padding: 16, flexDirection: "row", gap: 12 },
  signalIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: "rgba(255,255,255,0.55)", alignItems: "center", justifyContent: "center" },
  signalCopy: { flex: 1 },
  signalTitle: { color: colors.ink, fontSize: 14, fontWeight: "800" },
  signalBody: { color: "#5B5A70", fontSize: 11, lineHeight: 16, marginTop: 5 },
  startButton: { minHeight: 52, borderRadius: 16, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, marginTop: 5 },
  startPressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
  startButtonText: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  toast: { position: "absolute", bottom: 18, left: 20, right: 20, borderRadius: 14, backgroundColor: colors.ink, padding: 13, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 8 },
  toastText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
});
