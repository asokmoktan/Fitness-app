import { useState } from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";

const colors = { ink: "#171A17", muted: "#6E746B", bone: "#F6F4EC", card: "#FFFFFF", line: "#DDE0D4", lime: "#C7F36B", coral: "#FF8065", coralSoft: "#FFE3DC", lavender: "#E4DFFF" };
function ping() { if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
function ScoreRow({ label, value, color, icon }: { label: string; value: string; color: string; icon: "moon.stars.fill" | "brain.head.profile" | "figure.walk" }) { return <View style={styles.scoreRow}><View style={[styles.scoreIcon, { backgroundColor: color }]}><IconSymbol name={icon} size={17} color={colors.ink} /></View><View style={styles.scoreCopy}><Text style={styles.scoreLabel}>{label}</Text><Text style={styles.scoreValue}>{value}</Text></View><IconSymbol name="chevron.right" size={17} color={colors.muted} /></View>; }

export default function RecoverScreen() {
  const [checkIn, setCheckIn] = useState("Good");
  const [notice, setNotice] = useState("");
  const saveCheckIn = (value: string) => { ping(); setCheckIn(value); setNotice(`Recovery check-in saved · ${value}`); setTimeout(() => setNotice(""), 2200); };
  return <ScreenContainer className="px-5" containerClassName="bg-background"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
    <View style={styles.headerRow}><View><Text style={styles.eyebrow}>RECOVERY LAB</Text><Text style={styles.title}>Listen in.</Text></View><Pressable onPress={() => setNotice("Recovery history opened")} style={({ pressed }) => [styles.roundButton, pressed && styles.pressed]}><IconSymbol name="calendar" size={18} color={colors.ink} /></Pressable></View>
    <View style={styles.heroCard}><View style={styles.heroTop}><View><Text style={styles.heroEyebrow}>SYSTEM STATUS</Text><Text style={styles.heroTitle}>Ready to train.</Text><Text style={styles.heroBody}>Your inputs suggest you can handle moderate-to-high intensity today.</Text></View><View style={styles.heroScore}><Text style={styles.heroScoreValue}>86</Text><Text style={styles.heroScoreLabel}>READINESS</Text></View></View><View style={styles.heroFooter}><View style={styles.signalPill}><View style={styles.signalDot} /><Text style={styles.signalPillText}>ALL SYSTEMS NOMINAL</Text></View><Text style={styles.heroTrend}>+8 this week</Text></View></View>
    <View style={styles.sectionRow}><Text style={styles.sectionTitle}>Recovery signals</Text><Text style={styles.sectionMeta}>TODAY</Text></View>
    <View style={styles.signalList}><ScoreRow label="Sleep quality" value="7h 48m · 92% quality" color={colors.lavender} icon="moon.stars.fill" /><View style={styles.divider} /><ScoreRow label="Stress load" value="Low · 2 / 5" color={colors.lime} icon="brain.head.profile" /><View style={styles.divider} /><ScoreRow label="Muscle soreness" value="Low · 1 / 5" color={colors.coralSoft} icon="figure.walk" /></View>
    <View style={styles.sectionRow}><Text style={styles.sectionTitle}>Daily check-in</Text><Text style={styles.sectionMeta}>1 TAP</Text></View>
    <View style={styles.checkinCard}><Text style={styles.checkinTitle}>How are you feeling right now?</Text><Text style={styles.checkinBody}>Your answer helps PulseFit adjust today’s volume.</Text><View style={styles.checkinOptions}>{["Great", "Good", "Flat", "Rough"].map((option) => <Pressable key={option} onPress={() => saveCheckIn(option)} style={[styles.checkinOption, checkIn === option && styles.checkinOptionActive]}><Text style={[styles.checkinText, checkIn === option && styles.checkinTextActive]}>{option}</Text></Pressable>)}</View></View>
    <View style={styles.sectionRow}><Text style={styles.sectionTitle}>AI recovery note</Text><IconSymbol name="sparkles" size={18} color={colors.coral} /></View>
    <View style={styles.noteCard}><View style={styles.noteIcon}><IconSymbol name="sparkles" size={17} color={colors.ink} /></View><View style={styles.noteCopy}><Text style={styles.noteTitle}>Keep the plan — no deload needed</Text><Text style={styles.noteBody}>Your recent sleep and soreness trend supports the current training load. If stress rises above 4/5, we’ll automatically trim next week’s volume by 20%.</Text></View></View>
    <Pressable onPress={() => { ping(); setNotice("Wind-down reminder set for 10:30 PM"); setTimeout(() => setNotice(""), 2200); }} style={({ pressed }) => [styles.reminderButton, pressed && styles.reminderPressed]}><IconSymbol name="moon.stars.fill" size={17} color={colors.ink} /><Text style={styles.reminderText}>Set a 10:30 PM wind-down reminder</Text></Pressable>
  </ScrollView>{notice ? <View style={styles.toast}><IconSymbol name="checkmark" size={15} color={colors.ink} /><Text style={styles.toastText}>{notice}</Text></View> : null}</ScreenContainer>;
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 32, gap: 12 },
  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 18 },
  eyebrow: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.2 },
  title: { color: colors.ink, fontSize: 28, lineHeight: 34, fontWeight: "900", letterSpacing: -1, marginTop: 5 },
  roundButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  pressed: { opacity: 0.7 },
  heroCard: { backgroundColor: colors.lavender, borderRadius: 24, padding: 19, minHeight: 175 },
  heroTop: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
  heroEyebrow: { color: "#646078", fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  heroTitle: { color: colors.ink, fontSize: 25, lineHeight: 30, fontWeight: "900", letterSpacing: -0.7, marginTop: 8 },
  heroBody: { color: "#5B5A70", fontSize: 12, lineHeight: 17, maxWidth: 210, marginTop: 5 },
  heroScore: { width: 70, height: 70, borderRadius: 35, backgroundColor: "rgba(255,255,255,0.55)", alignItems: "center", justifyContent: "center" },
  heroScoreValue: { color: colors.ink, fontSize: 24, fontWeight: "900" },
  heroScoreLabel: { color: "#646078", fontSize: 8, fontWeight: "900", letterSpacing: 0.7, marginTop: 1 },
  heroFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 20 },
  signalPill: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.5)", borderRadius: 10, paddingVertical: 7, paddingHorizontal: 9 },
  signalDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#65A849" },
  signalPillText: { color: colors.ink, fontSize: 9, fontWeight: "900", letterSpacing: 0.7 },
  heroTrend: { color: "#646078", fontSize: 10, fontWeight: "800" },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 11, marginBottom: 2 },
  sectionTitle: { color: colors.ink, fontSize: 17, fontWeight: "800" },
  sectionMeta: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  signalList: { backgroundColor: colors.card, borderRadius: 21, paddingHorizontal: 15, paddingVertical: 4 },
  scoreRow: { minHeight: 67, flexDirection: "row", alignItems: "center", gap: 12 },
  scoreIcon: { width: 37, height: 37, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  scoreCopy: { flex: 1 },
  scoreLabel: { color: colors.ink, fontSize: 14, fontWeight: "800" },
  scoreValue: { color: colors.muted, fontSize: 11, marginTop: 4 },
  divider: { height: 1, backgroundColor: "#EFF0EA", marginLeft: 49 },
  checkinCard: { backgroundColor: colors.card, borderRadius: 21, padding: 17 },
  checkinTitle: { color: colors.ink, fontSize: 15, fontWeight: "800" },
  checkinBody: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 4 },
  checkinOptions: { flexDirection: "row", gap: 7, marginTop: 16 },
  checkinOption: { flex: 1, height: 38, borderRadius: 12, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  checkinOptionActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  checkinText: { color: colors.muted, fontSize: 11, fontWeight: "800" },
  checkinTextActive: { color: colors.lime },
  noteCard: { backgroundColor: colors.ink, borderRadius: 21, padding: 16, flexDirection: "row", gap: 12 },
  noteIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center" },
  noteCopy: { flex: 1 },
  noteTitle: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  noteBody: { color: "#B8C0B2", fontSize: 11, lineHeight: 16, marginTop: 6 },
  reminderButton: { height: 50, borderRadius: 15, borderWidth: 1, borderColor: colors.line, backgroundColor: "rgba(255,255,255,0.5)", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8 },
  reminderPressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
  reminderText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  toast: { position: "absolute", bottom: 18, left: 20, right: 20, borderRadius: 14, backgroundColor: colors.ink, padding: 13, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 8 },
  toastText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
});
