import { useState } from "react";
import { Alert, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import { startOAuthLogin } from "@/constants/oauth";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { setGuestMode } from "@/lib/profile";

const colors = { ink: "#171A17", muted: "#6E746B", bone: "#F6F4EC", card: "#FFFFFF", lime: "#C7F36B", coral: "#FF8065", line: "#DDE0D4" };

function tap() { if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }

export default function LoginScreen() {
  const [busy, setBusy] = useState(false);
  const continueWith = async (method: string) => {
    tap();
    if (method === "phone") {
      Alert.alert("Phone sign-in", "Phone verification will open in the secure account portal. Your profile will be tied to that account.");
    }
    setBusy(true);
    await setGuestMode(false);
    await startOAuthLogin();
    setTimeout(() => setBusy(false), 1200);
  };

  const continueAsGuest = async () => {
    tap();
    await setGuestMode(true);
    router.replace("/onboarding");
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background"><View style={styles.page}>
    <View style={styles.brandRow}><View style={styles.brandMark}><IconSymbol name="waveform.path.ecg" size={22} color={colors.ink} /></View><Text style={styles.brand}>PULSEFIT</Text></View>
    <View style={styles.hero}><Text style={styles.eyebrow}>YOUR BODY, YOUR PLAN</Text><Text style={styles.title}>Train with context.</Text><Text style={styles.subtitle}>Save your profile, keep your progress, and let PulseFit adapt to the person behind the numbers.</Text></View>
    <View style={styles.accountCard}><Text style={styles.cardTitle}>Save your progress</Text><Text style={styles.cardBody}>Choose a secure sign-in method. You’ll personalize your training profile next.</Text><Pressable onPress={() => continueWith("google")} disabled={busy} style={({ pressed }) => [styles.signInButton, pressed && styles.pressed]}><View style={styles.providerIcon}><Text style={styles.providerLetter}>G</Text></View><Text style={styles.signInText}>Continue with Google</Text><IconSymbol name="chevron.right" size={17} color={colors.muted} /></Pressable><Pressable onPress={() => continueWith("phone")} disabled={busy} style={({ pressed }) => [styles.signInButton, pressed && styles.pressed]}><View style={[styles.providerIcon, { backgroundColor: "#EAF6C9" }]}><IconSymbol name="phone" size={16} color={colors.ink} /></View><Text style={styles.signInText}>Continue with phone</Text><IconSymbol name="chevron.right" size={17} color={colors.muted} /></Pressable><Pressable onPress={() => continueWith("apple")} disabled={busy} style={({ pressed }) => [styles.signInButton, styles.appleButton, pressed && styles.pressed]}><View style={[styles.providerIcon, { backgroundColor: colors.ink }]}><IconSymbol name="apple" size={16} color="#FFFFFF" /></View><Text style={[styles.signInText, { color: "#FFFFFF" }]}>Continue with Apple</Text><IconSymbol name="chevron.right" size={17} color="#AAB2A2" /></Pressable></View>
    <View style={styles.dividerRow}><View style={styles.divider} /><Text style={styles.orText}>OR</Text><View style={styles.divider} /></View>
    <Pressable onPress={continueAsGuest} style={({ pressed }) => [styles.guestButton, pressed && styles.pressed]}><Text style={styles.guestText}>Continue without an account</Text></Pressable><Text style={styles.legal}>You can sign in later from Settings. Guest data stays on this device until you connect an account.</Text>
  </View></ScreenContainer>;
}

const styles = StyleSheet.create({ page: { flex: 1, paddingHorizontal: 22, paddingTop: 18, paddingBottom: 22, justifyContent: "space-between" }, brandRow: { flexDirection: "row", alignItems: "center", gap: 9 }, brandMark: { width: 36, height: 36, borderRadius: 13, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center" }, brand: { color: colors.ink, fontSize: 13, fontWeight: "900", letterSpacing: 2 }, hero: { marginTop: 50 }, eyebrow: { color: colors.coral, fontSize: 10, fontWeight: "900", letterSpacing: 1.4 }, title: { color: colors.ink, fontSize: 38, lineHeight: 42, fontWeight: "900", letterSpacing: -1.3, marginTop: 10 }, subtitle: { color: colors.muted, fontSize: 14, lineHeight: 21, maxWidth: 325, marginTop: 12 }, accountCard: { backgroundColor: colors.card, borderRadius: 24, padding: 17, shadowColor: colors.ink, shadowOpacity: 0.05, shadowRadius: 13, shadowOffset: { width: 0, height: 6 }, elevation: 2 }, cardTitle: { color: colors.ink, fontSize: 17, fontWeight: "900" }, cardBody: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 5, marginBottom: 15 }, signInButton: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.line, alignItems: "center", flexDirection: "row", paddingHorizontal: 11, gap: 10, marginTop: 8 }, appleButton: { backgroundColor: colors.ink, borderColor: colors.ink }, providerIcon: { width: 27, height: 27, borderRadius: 9, backgroundColor: "#F2F3EE", alignItems: "center", justifyContent: "center" }, providerLetter: { color: "#4285F4", fontWeight: "900", fontSize: 16 }, signInText: { flex: 1, color: colors.ink, fontSize: 12, fontWeight: "800" }, pressed: { opacity: 0.72, transform: [{ scale: 0.99 }] }, dividerRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 18 }, divider: { flex: 1, height: 1, backgroundColor: colors.line }, orText: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1 }, guestButton: { height: 49, borderRadius: 15, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center", marginTop: 12 }, guestText: { color: colors.ink, fontSize: 12, fontWeight: "900" }, legal: { textAlign: "center", color: colors.muted, fontSize: 10, lineHeight: 15, maxWidth: 300, alignSelf: "center", marginTop: 10 },
});
