import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  profile: router({
    get: protectedProcedure.query(({ ctx }) => db.getFitnessProfileByUserId(ctx.user.id)),
    upsert: protectedProcedure
      .input(z.object({
        firstName: z.string().max(100).optional(),
        age: z.string().max(16).optional(),
        sex: z.string().max(64).optional(),
        goal: z.string().max(64).optional(),
        heightCm: z.string().max(16).optional(),
        weightKg: z.string().max(16).optional(),
        bodyFat: z.string().max(16).optional(),
        targetWeightKg: z.string().max(16).optional(),
        activityLevel: z.string().max(64).optional(),
        trainingDays: z.string().max(64).optional(),
      }))
      .mutation(({ ctx, input }) => db.upsertFitnessProfile(ctx.user.id, input)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
