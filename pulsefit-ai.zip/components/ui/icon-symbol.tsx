// Fallback for using MaterialIcons on Android and web.
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "info.circle": "info-outline",
  "waveform.path.ecg": "monitor-heart",
  "moon.stars.fill": "bedtime",
  "drop.fill": "water-drop",
  "figure.strengthtraining.traditional": "fitness-center",
  "play.fill": "play-arrow",
  "pause.fill": "pause",
  "sparkles": "auto-awesome",
  "checkmark": "check",
  "plus": "add",
  "slider.horizontal.3": "tune",
  "chart.xyaxis.line": "show-chart",
  "sun.max.fill": "wb-sunny",
  "fork.knife": "restaurant",
  "bolt.fill": "bolt",
  "barcode.viewfinder": "qr-code-scanner",
  "brain.head.profile": "psychology",
  "figure.walk": "directions-walk",
  "calendar": "calendar-month",
  "chevron.left": "chevron-left",
  "phone": "phone",
  "apple": "apple",
  "lock": "lock",
} as IconMapping;

export function IconSymbol({ name, size = 24, color, style }: { name: IconSymbolName; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: SymbolWeight }) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
